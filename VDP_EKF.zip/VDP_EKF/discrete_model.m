function [x_k_km1, u] = discrete_model(x_km1,dt,mu,u)

x1_km1 = x_km1(1);
x2_km1 = x_km1(2);

x1_k_km1 = dt*x2_km1 + x1_km1;
x2_k_km1 = dt*(mu*(1-x1_km1^2)*x2_km1 - x1_km1 + u) + x2_km1;

x_k_km1 = [x1_k_km1 x2_k_km1]';

end