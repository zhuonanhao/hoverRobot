function H_k = JocobianH(x_k_km1)

mu = 1;
% State space variables
x1_k_km1 = x_k_km1(1);
x2_k_km1 = x_k_km1(2);

H_k = [x1_k_km1/norm(x_k_km1) x2_k_km1/norm(x_k_km1);
       -2*mu*x1_k_km1*x2_k_km1-1 mu*(1-x1_k_km1^2)+1;
       1 0;
       0 1];

end

