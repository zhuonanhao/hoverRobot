
%% Clear cache
clear;clc;close all

%% Initilization

x0 =randn(2,1);
tspan = 0:0.1:30;
mu = 1;
dt = mean(diff(tspan));

%% Noise profile
std_u = 1;
std_d = 3;
std_a = 1;
std_x = 5;

Q_k = [0 0; 0 (dt*std_u)^2];
R_k = diag([std_d, std_a, std_x, std_x])^2;
P_0_0 = 1*eye(2);

%% Simulate discrete model

x_discrete = zeros(2,size(tspan,2));
x_discrete(:,1) = x0;
u = std_u*randn(size(tspan));

for i = 2:length(tspan)
    x_discrete(:,i) = discrete_model(x_discrete(:,i-1), dt, mu, u(i)); 
end


%% Generate measurement
[x_1,x_2,d,a,x_1_mea,x_2_mea,d_mea,a_mea] = genMeasure(tspan, x_discrete, mu, std_d, std_a, std_x);

%% Visulize input, trajectory, and output

figure(1)
subplot(3,2,1)
hold on
plot(tspan, u, 'b.','LineWidth',3)
plot(tspan, zeros(size(tspan)), 'k-','LineWidth',3)
xlabel('time, t [s]')
ylabel('input u')
title('Input')
% legend('Measurement', 'Ground truth')
box on

subplot(3,2,2)
hold on
plot(x_discrete(1,:), x_discrete(2,:), 'b.','LineWidth',3)
xlabel('x_1, [m]')
ylabel('x_2, [m]')
title('Trajectory')
% legend('Measurement', 'Ground truth')
box on

subplot(3,2,3)
hold on
plot(tspan, d_mea, 'b.','LineWidth',3)
plot(tspan, d, 'k-','LineWidth',3)
xlabel('time, t [s]')
ylabel('distance d, [m]')
title('Distance')
% legend('Measurement', 'Ground truth')
box on

subplot(3,2,4)
hold on
plot(tspan, a_mea, 'b.','LineWidth',3)
plot(tspan, a, 'k-','LineWidth',3)
xlabel('time, t [s]')
ylabel('acceleration a')
title('Acceleration')
% legend('Measurement', 'Ground truth')
box on

subplot(3,2,5)
hold on
plot(tspan, x_1_mea, 'b.','LineWidth',3)
plot(tspan, x_1, 'k-','LineWidth',3)
xlabel('time, t [s]')
ylabel('state x_1, [m]')
title('State 1')
% legend('Measurement', 'Ground truth')
box on

subplot(3,2,6)
hold on
plot(tspan, x_2_mea, 'b.','LineWidth',3)
plot(tspan, x_2, 'k-','LineWidth',3)
xlabel('time, t [s]')
ylabel('state x_2, [m]')
title('State 2')
% legend('Measurement', 'Ground truth')
box on
%% Define output function handle

h = @(x,y) ...
    [sqrt(x.^2+y.^2);
    mu*(1-x.^2).*y-x;
    x;
    y];

%% Extended Kalman filter

% Initialize variables
x_hat = zeros(2,size(tspan,2));
filter_mea = zeros(4,size(tspan,2));
x_hat(:,1) = x0;
x_hat_km1_km1 = x0;
P_km1_km1 = P_0_0;

for i = 2:length(tspan)

    % Predict state estimate 
    x_hat_k_km1 = discrete_model(x_hat_km1_km1, dt, mu, 0);

    % State transition and observation matrices
    F_k = JocobianF(x_hat_km1_km1, dt);
    H_k = JocobianH(x_hat_k_km1);

    % Predict covariance estimate 
    P_k_km1 = F_k*P_km1_km1*F_k' + Q_k;

    % Measurement residual
    y_hat_k = [d_mea(i); a_mea(i); x_1_mea(i); x_2_mea(i)] - h(x_hat_k_km1(1), x_hat_k_km1(2));

    % Residual covariance 
    S_k = H_k * P_k_km1 * H_k' + R_k;

    % Near-optimal Kalman gain
    K_k = P_k_km1 * H_k' * inv(S_k);

    % Updated state estimate 
    x_hat_k_k = x_hat_k_km1 + K_k * y_hat_k;

    % Updated covariance estimate 
    P_k_k = (eye(2) - K_k * H_k) * P_k_km1;
    
    % Update variable
    x_hat(:,i) = x_hat_k_k;
    x_hat_km1_km1 = x_hat_k_k;
    P_km1_km1 = P_k_k;

    filter_mea(:,i) = h(x_hat_k_k(1),x_hat_k_k(2));

end

%%

d_hat = filter_mea(1,:);
a_hat = filter_mea(2,:);
x_1_hat = filter_mea(3,:);
x_2_hat = filter_mea(4,:);

figure(2)
subplot(2,2,1)
hold on
plot(tspan, d_mea,'b.')
plot(tspan, d_hat,'r-', 'LineWidth', 2)
plot(tspan, d, 'k-', 'LineWidth', 2)
xlabel('time, t [sec]')
ylabel('distance d, [m]')
legend('measurement','filter', 'truth')
title('Distance')
box on

subplot(2,2,2)
hold on
plot(tspan, a_mea,'b.')
plot(tspan, a_hat,'r-', 'LineWidth', 2)
plot(tspan, a, 'k-', 'LineWidth', 2)
xlabel('time, t [sec]')
ylabel('acceleration a, [m/s^2]')
legend('measurement','filter', 'truth')
title('Acceleration')
box on

subplot(2,2,3)
hold on
plot(tspan, x_1_mea,'b.')
plot(tspan, x_1_hat,'r-', 'LineWidth', 2)
plot(tspan, x_1, 'k-', 'LineWidth', 2)
legend('measurement','filter', 'truth')
xlabel('time, t [s]')
ylabel('state x_2, [m]')
title('State 2')
box on

subplot(2,2,4)
hold on
plot(tspan, x_2_mea,'b.')
plot(tspan, x_2_hat,'r-', 'LineWidth', 2)
plot(tspan, x_2, 'k-', 'LineWidth', 2)
legend('measurement','filter', 'truth')
xlabel('time, t [s]')
ylabel('state x_1, [m]')
title('State 1')
box on




