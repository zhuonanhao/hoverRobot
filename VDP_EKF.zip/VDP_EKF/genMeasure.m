function [x_1,x_2,d,a,x_1_mea,x_2_mea,d_mea,a_mea] = genMeasure(tspan, x, mu, std_d, std_a, std_x)

N = length(tspan);

x_1 = x(1,:);
x_2 = x(2,:);

x_1_mea = x_1 + std_x*randn(1,N);
x_2_mea = x_2 + std_x*randn(1,N);

d = sqrt(x_1.^2 + x_2.^2);
d_mea = d + std_d*randn(1,N);
a = mu*(1-x(1,:).^2).*x(2,:) - x(1,:);
a_mea = a + std_a*randn(1,N);

end

