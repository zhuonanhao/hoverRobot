function dx = continous_model(t,x)

x1 = x(1);
x2 = x(2);

mu = 1;

u = sin(t);
dx1 = x2;
dx2 = mu*(1-x1^2)*x2 - x1 + u;

dx = [dx1 dx2]';


end

