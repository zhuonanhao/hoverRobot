function F_k = JocobianF(x_km1,dt)

mu = 1;

% State space variables
x1_km1 = x_km1(1);
x2_km1 = x_km1(2);

F_k = [1 dt;
       -dt*(2*mu*x1_km1*x2_km1+1) dt*mu*(1-x1_km1^2)+1];

end

